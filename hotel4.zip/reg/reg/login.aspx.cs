﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace WebApplication1
{
    public partial class login : System.Web.UI.Page
    {
        //Business_Layer BL = new Business_Layer();
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            //if (TextBox1.Text == "admin" && TextBox2.Text == "password")
            //{
            //    Response.Redirect("Admin.aspx");
            //}
            //else
            //{
            //    User_Object UO = new User_Object();
            //    UO.Email = TextBox1.Text;
            //    UO.Password = TextBox2.Text;
            //    int str = Convert.ToInt32(BL.User_Login_BL(UO));
            //    if (str == 1)
            //    {
            //        Response.Redirect("Profile.aspx");

            //    }
            //    else if (str == 0)
            //    {
            //        Label1.Text = "Login Unsuccesfull ... Please Try Again !!";
            //    }
            //}
        }
}
}